
## Exchanges
coinbase: https://developers.coinbase.com/api/v2#pagination sander
binance julian
bitstamp
bitfinex

## TODO
1. Bitcoin live ticker via api maken
2. Tabel met gemiddelde waarde

